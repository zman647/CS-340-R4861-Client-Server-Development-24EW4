import pymongo
from pymongo import MongoClient

class MongoCRUD:
    def __init__(self, db_name, collection_name, host, port, username, password, authSource='admin'):
        self.client = MongoClient(
            host=host, 
            port=port, 
            username=username, 
            password=password, 
            authSource=authSource
        )
        self.db = self.client[db_name]
        self.collection = self.db[collection_name]

    def create(self, document):
        try:
            self.collection.insert_one(document)
            return True
        except Exception as e:
            print(f"An error occurred: {e}")
            return False

    def read(self, query):
        try:
            return list(self.collection.find(query))
        except Exception as e:
            print(f"An error occurred: {e}")
            return []

    def update(self, query, new_values):
        try:
            result = self.collection.update_many(query, {'$set': new_values})
            return result.modified_count
        except Exception as e:
            print(f"An error occurred: {e}")
            return 0

    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"An error occurred: {e}")
            return 0
